import React from 'react';

const About = () => {
  return (
    <section>
      <h2>About Me</h2>
      <p>
        Hi there! I'm, a dedicated and enthusiastic web developer.I love bringing creativity,
        attention to detail, and a passion for crafting seamless user experiences.
      
      </p>
      
    </section>
  );
};

export default About;

