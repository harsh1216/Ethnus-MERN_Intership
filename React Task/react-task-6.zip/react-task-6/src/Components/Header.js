import React from 'react';

const Header = () => {
  return (
    <header>
      <h1>me</h1>
      <p>Web Developer</p>
    </header>
  );
}

export default Header;
